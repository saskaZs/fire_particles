import {
  require_react
} from "./chunk-H5I4P4DR.js";
export default require_react();
