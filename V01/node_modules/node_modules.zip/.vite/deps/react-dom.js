import {
  require_react_dom
} from "./chunk-5SC5K45T.js";
import "./chunk-H5I4P4DR.js";
export default require_react_dom();
